<template>
    <div class="logo-mob">
        <img src="@/assets/images/logoMob.svg" alt="">
    </div>
    <div class="tech-header container">
        <h1>Tech Stack</h1>
        <span>The dev tools, apps, devices, and games I use and play.</span>
            <div class="effectt">
                <div ref="blob al" class="blobb al"></div>
            </div>
    </div>
    <div class="header-line"></div>
    <div class="tech-main container">
        <div class="tech-main-section">
            <h2>Dev & Design</h2>
            <div class="tech-main-section-catalog">
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/Figma.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Figma</p>
                        <span>Design</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/Github.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Github</p>
                        <span>Project management</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/VSCode.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>VS code</p>
                        <span>Editor</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/js.svg" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>JS</p>
                        <span>Language</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/vue.png" class="no" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Vue JS</p>
                        <span>Framework</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/sass.png" class="no" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Sass</p>
                        <span>Stylesheets</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/ax.png" class="no-nah" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Axios</p>
                        <span>HTTP requests</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/pinia.png" class="no-pinia" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Pinia</p>
                        <span>Vue library</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/html.png" class="no" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>HTML</p>
                        <span>Markup</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="tech-main-section">
            <h2>Apps</h2>
            <div class="tech-main-section-catalog">
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/ChatGPT.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Chat GPT</p>
                        <span>Productivity</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/Discord.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Discord</p>
                        <span>Communication</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/Chrome.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Chrome</p>
                        <span>Browser</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/Spotify.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Spotify</p>
                        <span>Music</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/stack.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Stack Overflow</p>
                        <span>Solutions</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/cpen.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>CodePen</p>
                        <span>Inparation</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/tube.png" class="no" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Youtube</p>
                        <span>Entertainment</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/telegram.png" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Telegram</p>
                        <span>Communication</span>
                    </div>
                </div>
                <div class="tech-main-section-catalog-card">
                    <img src="@/assets/images/health.png" class="no" alt="">
                    <div class="tech-main-section-catalog-card-info">
                        <p>Health</p>
                        <span>Physical condition</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>